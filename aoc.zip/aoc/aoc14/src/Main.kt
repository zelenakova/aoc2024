import java.io.File
import kotlin.math.roundToInt
import kotlin.math.sqrt

fun main() {
    val lines = File("input.txt").readLines()
    val robots = mutableListOf<Robot>()
    for (line in lines) {
        val parts = line.split(" ")
        val positionParts = parts[0].substring(2, parts[0].length).split(",")
        val velocityParts = parts[1].substring(2, parts[1].length).split(",")
        val px = positionParts[0].toInt()
        val py = positionParts[1].toInt()
        val vx = velocityParts[0].toInt()
        val vy = velocityParts[1].toInt()
        robots.add(Robot(px, py, vx, vy))
    }
    for (time in 1..10000) {
        val finalPositions = robots.map { move(it, time) }
        val averageX = countAverageX(finalPositions)
        val differenceX = countDifferenceX(finalPositions, averageX)
        val averageY = countAverageY(finalPositions)
        val differenceY = countDifferenceY(finalPositions, averageY)
        if ((differenceX < 21) && (differenceY < 25)) {
            println("PositionX $time $averageX $differenceX")
            println("PositionY $time $averageY $differenceY")
            printPositions(finalPositions)
            //break
        }

    }

}


data class Robot(val px: Int, val py: Int, val vx: Int, val vy: Int)

fun move(robot: Robot, time: Int): Pair<Int, Int> {
    val newPx = ((robot.px + robot.vx * time) % 101 + 101) % 101
    val newPy = ((robot.py + robot.vy * time) % 103 + 103) % 103
    return Pair(newPx, newPy)
}

fun count(positions: List<Pair<Int, Int>>): Map<String, Int> {
    val middleX = 101 / 2
    val middleY = 103 / 2

    val counts = mutableMapOf("TL" to 0, "TR" to 0, "BL" to 0, "BR" to 0)

    for ((x, y) in positions) {
        if (x == middleX || y == middleY) continue

        if (x < middleX && y < middleY) {
            counts["TL"] = counts["TL"]!! + 1
        } else if (x >= middleX && y < middleY) {
            counts["TR"] = counts["TR"]!! + 1
        } else if (x < middleX && y >= middleY) {
            counts["BL"] = counts["BL"]!! + 1
        } else {
            counts["BR"] = counts["BR"]!! + 1
        }
    }

    return counts
}
fun printPositions(positions: List<Pair<Int, Int>>) {
    val minX = positions.minOf { it.first }
    val maxX = positions.maxOf { it.first }
    val minY = positions.minOf { it.second }
    val maxY = positions.maxOf { it.second }

    val grid = Array(maxY - minY + 1) { CharArray(maxX - minX + 1) { '.' } }

    for ((x, y) in positions) {
        grid[y - minY][x - minX] = '#'
    }

    grid.forEach { println(it.concatToString()) }
    println("-----------------------")
}
fun countAverageX(positions: List<Pair<Int, Int>>): Int {
    var average = 0F
    for ((x, y) in positions) average += x
    return (average/500).roundToInt()
}
fun countDifferenceX(positions: List<Pair<Int, Int>>, average: Int): Int {
    var difference = 0
    for ((x, y) in positions) {
        difference += (average - x)*(average - x)
    }
    return (sqrt(difference.toFloat()/500)).roundToInt()
}
fun countAverageY(positions: List<Pair<Int, Int>>): Int {
    var average = 0F
    for ((x, y) in positions) average += y
    return (average/500).roundToInt()
}
fun countDifferenceY(positions: List<Pair<Int, Int>>, average: Int): Int {
    var difference = 0
    for ((x, y) in positions) {
        difference += (average - y)*(average - y)
    }
    return (sqrt(difference.toFloat()/500)).roundToInt()
}