import java.io.File

lateinit var land: Array<Array<String>>
lateinit var trails: Array<Array<MutableList<Pair<Int, Int>>>>
val valueStart = "0"
val valueFinish = "9"
val directions = arrayOf(Pair(-1, 0), Pair(0,1), Pair(1,0), Pair(0,-1))
var n = 0

fun main() {

    val text = File("input.txt").readLines()
    n = text.size
    land = Array(n) { Array<String>(n) { "." } }
    trails = Array(n) { Array(n) { mutableListOf<Pair<Int, Int>>() }}
    var count = Array(n) { Array<Int>(n) { 0 } }

    var i = 0
    for (line: String in text) {
        //println(line)
        var j = 0
        for (one: Char in line) {
            //println(one)
            land[i][j] = one.toString()
            j++
        }
        i++
    }
    //najdi trailheads
    for (i in land.indices) {
        for (j in land[i].indices) {
            if (land[i][j].contains(valueStart)) {
                //println("Trailhead: $i, $j")
                findNext(Pair(i, j), Pair(i, j))
            }
        }
    }
    for (i in trails.indices) {
        for (j in trails[i].indices) {
            count[i][j] = trails[i][j].size
        }
    }
    println("Suma skore: ${count.flatten().sum()}")

}

fun findNext(start: Pair<Int, Int>, trailhead: Pair<Int, Int>) {
    //println("findNext: $start $trailhead")
    if (land[start.first][start.second].contains(valueFinish)) {
        //if (!(trails[trailhead.first][trailhead.second].contains(start))) {
        trails[trailhead.first][trailhead.second].add(start)
        //println("Nasiel som: ${trailhead.first} ${trailhead.second} ${trails[trailhead.first][trailhead.second]}")
        //}
    }
    for (direction in directions) {
        //println("direction: $direction")
        if (neighbourSuitable(start, direction, (land[start.first][start.second].toInt() + 1).toString())) {
            findNext(sumPairs(start, direction), trailhead)
        }
    }
}

fun neighbourSuitable(position: Pair<Int, Int>, direction: Pair<Int, Int>, value: String): Boolean {
    val neighbour = sumPairs(position, direction)
    //println("Neighbour a value: $neighbour $value" )
    if ((neighbour.first < 0) || (neighbour.first >= n)) return false
    if ((neighbour.second < 0) || (neighbour.second >= n)) return false
    if (!land[neighbour.first][neighbour.second].contains(value)) return false
    return true
}

fun sumPairs(pair1: Pair<Int, Int>, pair2: Pair<Int, Int>): Pair<Int, Int> {
    return Pair(pair1.first + pair2.first, pair1.second + pair2.second)
}