import java.io.File

fun main() {
    val text = File("input.txt").readLines()
    val warehouse = mutableListOf<CharArray>()
    val moves = StringBuilder()
    var robotPosition = Pair(0, 0)

    for (line in text) {
        if (line.startsWith("#")) {
            warehouse.add(line.toCharArray())
            if (line.contains('@')) {
                robotPosition = Pair(warehouse.size - 1, line.indexOf('@'))
            }
        } else {
            moves.append(line.trim())
        }
    }

    val directions = mapOf(
        '<' to Pair(0, -1),
        '>' to Pair(0, 1),
        '^' to Pair(-1, 0),
        'v' to Pair(1, 0)
    )

    fun printWarehouse() {
        warehouse.forEach { println(it.concatToString()) }
        println()
    }

    for (move in moves) {
        //println("Move: $move")
        val (dx, dy) = directions[move] ?: continue
        val (x, y) = robotPosition
        val newX = x + dx
        val newY = y + dy

        if (newX in warehouse.indices && newY in warehouse[newX].indices) {
            if (warehouse[newX][newY] == '.') {
                warehouse[x][y] = '.'
                warehouse[newX][newY] = '@'
                robotPosition = Pair(newX, newY)
            } else if (warehouse[newX][newY] == 'O') {
                var currentX = newX
                var currentY = newY
                val boxPositions = mutableListOf<Pair<Int, Int>>()

                while (currentX in warehouse.indices && currentY in warehouse[currentX].indices && warehouse[currentX][currentY] == 'O') {
                    boxPositions.add(Pair(currentX, currentY))
                    currentX += dx
                    currentY += dy
                }

                if (currentX in warehouse.indices && currentY in warehouse[currentX].indices && warehouse[currentX][currentY] == '.') {
                    // Move the boxes
                    for (i in boxPositions.size - 1 downTo 0) {
                        val (boxX, boxY) = boxPositions[i]
                        val newBoxX = boxX + dx
                        val newBoxY = boxY + dy
                        warehouse[newBoxX][newBoxY] = 'O'
                        warehouse[boxX][boxY] = '.'
                    }
                    warehouse[newX][newY] = '@'
                    warehouse[x][y] = '.'
                    robotPosition = Pair(newX, newY)
                }
            }
        }
        //printWarehouse()
    }
    var sumGpsCoordinates = 0
    for (i in warehouse.indices) {
        for (j in warehouse[i].indices) {
            if (warehouse[i][j] == 'O') {
                sumGpsCoordinates += 100 * i + j
            }
        }
    }

    println(sumGpsCoordinates)
}