import java.io.File

fun main() {
    val text = File("input.txt").readText()
    //val regex = Regex("""mul\((\d+),(\d+)\)""")
    val regex = Regex("""mul\((\d+),(\d+)\)|do\(\)|don't\(\)""")
    var isEnabled = true
    var sum = 0

    for (match in regex.findAll(text)) {
        val matchText = match.value
        if (matchText.startsWith("mul") && isEnabled) {
            val start = matchText.indexOf('(') + 1
            val end = matchText.indexOf(')')
            val numbers = matchText.substring(start, end)
            val (x, y) = numbers.split(',').map { it.toInt() }
            sum += x * y
        } else if (matchText == "do()") {
            isEnabled = true
        } else if (matchText == "don't()") {
            isEnabled = false
        }
    }

    println(sum)
}
