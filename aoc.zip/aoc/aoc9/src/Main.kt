import java.io.File

fun main() {
    val input = File("input.txt").readLines()[0]
    val text = translate(input)

//    var index = text.size - 1
    var sum = 0L
//    for (i in text.indices) {
//        if (index > i && text[i] == -1L) {
//            val switch = find(i, index, text)
//            if (switch.first == -1) break
//            index = switch.first
//            text[index] = -1
//            text[i] = switch.second
//        }
//        if (text[i] != -1L) {
//            sum += i * text[i]
//        }
//    }
//    println(sum)

    var fileId = -1L
    var fileStop = text.size - 1

    while (fileStop >= 0) {
        while (fileStop >= 0 && text[fileStop] == -1L) {
            fileStop--
        }
        if (fileStop < 0) break

        fileId = text[fileStop]

        var fileStart = fileStop
        while (fileStart >= 0 && text[fileStart] == fileId) {
            fileStart--
        }
        fileStart++

        var freeStart = 0
        while (freeStart < fileStart) {
            while (freeStart < fileStart && text[freeStart] != -1L) {
                freeStart++
            }
            if (freeStart >= text.size) break

            var freeStop = freeStart
            while (freeStop < fileStart && text[freeStop] == -1L) {
                freeStop++
            }
            freeStop--

            if ((freeStop - freeStart + 1) >= (fileStop - fileStart + 1)) {
                val length = fileStop - fileStart
                for (j in 0..length) {
                    text[freeStart + j] = fileId
                }
                for (j in 0..length) {
                    text[fileStart + j] = -1L
                }
                break
            }
            freeStart = freeStop + 1
        }
        fileStop = fileStart - 1
    }
    sum = 0L
    for ((i, value) in text.withIndex()) {
        if (value != -1L) sum += i * value
    }
    println(sum)
}

fun find(front: Int, back: Int, text: List<Long>): Pair<Int, Long> {
    for (i in back downTo front + 1) {
        if (text[i] != -1L) {
            return Pair(i, text[i])
        }
    }
    return Pair(-1, -1)
}

fun translate(input: String): MutableList<Long> {
    val ret = mutableListOf<Long>()
    var fileId = 0L
    var isFile = true

    for (lengthChar in input) {
        val length = lengthChar.toString().toInt()
        if (isFile) {
            for (i in 0 until length) {
                ret.add(fileId)
            }
            if (length > 0) fileId++
        } else {
            for (i in 0 until length) {
                ret.add(-1)
            }
        }
        isFile = !isFile
    }
    return ret
}
