import java.io.File

fun main() {
    val input = File("input.txt").readText()
    val sections = input.split("\r\n\r\n")
    val rules = sections[0].lines().map { it.split("|").let { it[0].toInt() to it[1].toInt() } }
    val updates = sections[1].lines().map { it.split(",").map { it.toInt() } }

    fun isUpdateValid(update: List<Int>, rules: List<Pair<Int, Int>>): Boolean {
        for ((x, y) in rules) {
            val indexX = update.indexOf(x)
            val indexY = update.indexOf(y)
            if (indexX != -1 && indexY != -1 && indexX > indexY) {
                return false
            }
        }
        return true
    }

    fun sort(update: List<Int>, rules: List<Pair<Int, Int>>): List<Int> {
        val sorted = mutableListOf<Int>()
        val remaining = update.toMutableSet()

        while (remaining.isNotEmpty()) {
            for (page in remaining.toList()) {
                if (rules.none { it.second == page && remaining.contains(it.first) }) {
                    sorted.add(page)
                    remaining.remove(page)
                }
            }
        }
        return sorted
    }

    val validUpdates = updates.filter { isUpdateValid(it, rules) }
    val middleSumValid = validUpdates.sumOf { it[it.size / 2] }
    var invalidUpdates = updates.filter { !isUpdateValid(it, rules) }
    invalidUpdates = invalidUpdates.map { sort(it, rules) }
    val middleSumInvalid = invalidUpdates.sumOf { it[it.size / 2] }

    println(middleSumValid)
    println(middleSumInvalid)
}
