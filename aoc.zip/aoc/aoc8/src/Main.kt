import java.io.File
import kotlin.math.abs

fun main() {
    val text = File("input.txt").readLines()
    val n = text.size
    var lab = Array(n) { Array<String>(n) { "." } }
    var count = Array(n) { Array<Int>(n) { 0 } }

    //println("n= $n")
    var i = 0
    for (line: String in text) {
        var j = 0
        for (one: Char in line) {
            //print(one)
            lab[i][j] = one.toString()
            j++
        }
        //println()
        i++
    }

    for (i in lab.indices) {
        for (j in lab[i].indices) {
            if (lab[i][j].contains(".")) continue
            //println("Hladam: ${lab[i][j]}")
            for (ii in i..n - 1) {
                for (jj in lab[ii].indices) {
                    if ((ii == i) && (jj <= j)) continue
                    if (lab[ii][jj].contains(lab[i][j])) {
                        //println("Nasiel som: ${lab[ii][jj]}")
                        val di = ii - i
                        val dj = jj - j
                        val uij = upravDiDj(di, dj)
                        val ui = uij.first
                        val uj = uij.second
                        count[i][j] = 1
                        var continueDown = true
                        var continueUp = true
                        var k = 1
                        do {
                            if ((continueDown == true) && (i - k*ui >= 0) && (j - k*uj >= 0) && (i - k*ui <= n - 1) && (j - k*uj <= n - 1)) count[i - k*ui][j - k*uj] = 1
                            else continueDown = false
                            if ((continueUp == true) && (i + k*ui >= 0) && (j + k*uj >= 0) && (i + k*ui <= n - 1) && (j + k*uj <= n - 1)) count[i + k*ui][j + k*uj] = 1
                            else continueUp = false
                            k += 1
                        } while ((continueDown == true) || (continueUp == true))
                    }
                }
            }
        }
    }
    println("Pocet antinodov: ${count.flatten().sum()}")
    /*
    for (i in count.indices) {
        for (j in count[i].indices) {
            if (count[i][j] == 0) print(".")
            if (count[i][j] == 1) print("#")
        }
        println()
    }*/
}

fun upravDiDj(di: Int, dj: Int): Pair<Int, Int> {
    val gcdValue = gcd(abs(di), abs(dj))
    var ui = di /gcdValue
    var uj = dj /gcdValue
    return Pair(ui, uj)
}

fun gcd(a: Int, b: Int): Int {
    return (if (b == 0) a else gcd(b, a % b))
}
