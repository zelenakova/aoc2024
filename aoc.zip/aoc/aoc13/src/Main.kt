import java.io.File
import kotlin.math.*

fun main() {
    val lines = File("input.txt").readLines()
    val machines = mutableListOf<Machine>()
    for (i in lines.indices step 4) {
        val buttonA = lines[i].substring(10, lines[i].length).split(", ")
        val xA = buttonA[0].substring(2, buttonA[0].length).toInt()
        val yA = buttonA[1].substring(2, buttonA[1].length).toInt()

        val buttonB = lines[i + 1].substring(10, lines[i + 1].length).split(", ")
        val xB = buttonB[0].substring(2, buttonB[0].length).toInt()
        val yB = buttonB[1].substring(2, buttonB[1].length).toInt()

        val prize = lines[i + 2].substring(7, lines[i + 2].length).split(", ")
        val xP = prize[0].substring(2, prize[0].length).toInt()
        val yP = prize[1].substring(2, prize[1].length).toInt()

        machines.add(Machine(xA, yA, xB, yB, xP, yP))
    }
    val results = machines.map { solve(it) }
    val total = results.filterNotNull().sum()

    println(total)
}

data class Machine(val xA: Int, val yA: Int, val xB: Int, val yB: Int, val xP: Int, val yP: Int)

fun solve(machine: Machine): Int? {
    val (xA, yA, xB, yB, xP, yP) = machine
    var min: Int? = null
    for (a in 0..99) {
        val remainingX = xP - a * xA
        val remainingY = yP - a * yA

        if (remainingX % xB == 0 && remainingY % yB == 0) {
            val bX = remainingX / xB
            val bY = remainingY / yB

            if (bX == bY && bX >= 0) {
                val cost = 3 * a + bX
                if (min == null || cost < min) {
                    min = cost
                }
            }
        }
    }
    return min
}
