import java.io.File
lateinit var land: Array<Array<String>>
lateinit var landCounted: Array<Array<Boolean>>
lateinit var polia: Array<Array<Boolean>>
lateinit var rohy: Array<Array<Int>>
var n = 0

fun main() {
    val inputs = File("input.txt").readLines()
    n = inputs.size
    land = Array(n) { Array<String>(n) { "." } }
    landCounted = Array(n) { Array<Boolean>(n) { false } }
    polia = Array(n) { Array<Boolean>(n) { false }}
    rohy = Array(n+1) { Array<Int>(n+1) { 0 } }
    var count: Array<Pair<Int, Int>> = Array(n*n) {Pair(0,0)}
    var countName: Array<String> = Array(n*n) {""}

    var i = 0
    for (line: String in inputs) {
        //println(line)
        var j = 0
        for (one: Char in line) {
            //println(one)
            land[i][j] = one.toString()
            landCounted[i][j] = false
            j++
        }
        i++
    }
    var index = 0
    for (i in land.indices) {
        for (j in land[i].indices) {
            if (landCounted[i][j] == false) {
                clearRohyPolia()
                countName[index] = land[i][j]
                count[index] = countRegion(i,j)
                var vadneRohy = checkPolia()
                if (vadneRohy.mod(2) != 0) vadneRohy +=1
                count[index] = Pair( rohy.flatten().sum() + vadneRohy,count[index].second)
                index++
            }
        }
    }

    var sum = 0
    i = 0
    count.forEach { entry ->
        //println("Pozemky ${countName[i]} obvod ${entry.first} obsah ${entry.second} SUMA: ${entry.first*entry.second}")
        sum+=entry.first * entry.second
        i++
    }
    println("Cena vsetkych plotov: $sum")
}

fun countRegion(i: Int, j: Int): Pair<Int, Int> {
    var countR = Pair(4,1)
    setRohy(i,j)
    landCounted[i][j] = true
    polia[i][j] = true
    if ((exist(i-1, j) == true) && (land[i-1][j] == land[i][j])) {
        countR = Pair(countR.first.plus(-1), countR.second)
        if (landCounted[i-1][j] == false) {
            val temp = countRegion(i - 1, j)
            countR = Pair(countR.first.plus(temp.first), countR.second.plus(temp.second))
        }
    }
    if ((exist(i, j+1) == true) && (land[i][j+1] == land[i][j])) {
        countR = Pair(countR.first.plus(-1), countR.second)
        if (landCounted[i][j+1] == false) {
            val temp = countRegion(i, j+1)
            countR = Pair(countR.first.plus(temp.first), countR.second.plus(temp.second))
        }
    }
    if ((exist(i+1, j) == true) && (land[i+1][j] == land[i][j])) {
        countR = Pair(countR.first.plus(-1), countR.second)
        if (landCounted[i+1][j] == false) {
            val temp = countRegion(i+1, j)
            countR = Pair(countR.first.plus(temp.first), countR.second.plus(temp.second))
        }
    }
    if ((exist(i, j-1) == true) && (land[i][j-1] == land[i][j])) {
        countR = Pair(countR.first.plus(-1), countR.second)
        if (landCounted[i][j-1] == false) {
            val temp = countRegion(i, j-1)
            countR = Pair(countR.first.plus(temp.first), countR.second.plus(temp.second))
        }
    }
    return countR
}

fun setRohy(i: Int, j:Int) {
    rohy[i][j] = 1 - rohy[i][j]
    rohy[i+1][j] = 1 - rohy[i+1][j]
    rohy[i][j+1] = 1 - rohy[i][j+1]
    rohy[i+1][j+1] = 1 - rohy[i+1][j+1]
}

fun checkPolia(): Int {
    var pocet = 0
    for (i in 0..n-1)
        for (j in 0..n-1) {
            var poleGood = true
            if (polia[i][j] == true) {
                if ((poleGood == true) && (exist(i - 1, j - 1) == true) && (polia[i - 1][j - 1] == true)) poleGood = isPoleGood(i, j, i - 1, j - 1)
                if ((poleGood == true) && (exist(i+1, j + 1) == true) && (polia[i+1][j + 1] == true)) poleGood = isPoleGood(i, j, i + 1, j + 1)
                if ((poleGood == true) && (exist(i - 1, j+1) == true) && (polia[i - 1][j+1] == true)) poleGood = isPoleGood(i, j, i - 1, j + 1)
                if ((poleGood == true) && (exist(i+1, j - 1) == true) && (polia[i+1][j - 1] == true)) poleGood = isPoleGood(i, j, i + 1, j - 1)
            }
            if (poleGood == false) {
                pocet += 1
                //println("vadny roh $i $j")
            }
        }
    return pocet
}

fun isPoleGood(i: Int, j:Int, i2: Int, j2:Int):Boolean {
    if ((polia[i][j2] == true) || (polia[i2][j] == true)) return true
    else return false
}

fun clearRohyPolia() {
    for (i in 0..n)
        for (j in 0..n) {
            rohy[i][j] = 0
            if ((i<n)&&(j<n)) polia[i][j] = false
        }
}

fun zistiObvod(i: Int, j:Int):Int {
    var obvod = 4
    if ((exist(i-1, j) == true) && (land[i-1][j] == land[i][j])) obvod -= 1
    if ((exist(i, j+1) == true) && (land[i][j+1] == land[i][j])) obvod -= 1
    if ((exist(i+1, j) == true) && (land[i+1][j] == land[i][j])) obvod -= 1
    if ((exist(i, j-1) == true) && (land[i][j-1] == land[i][j])) obvod -= 1
    return obvod
}

fun exist(i: Int, j:Int):Boolean{
    if ((i>=0) && (i<n) && (j>=0) && (j<n)) return true
    return false
}