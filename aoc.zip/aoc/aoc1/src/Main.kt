import java.io.File

fun main() {
    val text = File("input.txt").readLines()

    val left = mutableListOf<Int>()
    val right = mutableListOf<Int>()

    for (line in text) {
        val parts = line.split("   ")
        left.add(parts[0].toInt())
        right.add(parts[1].toInt())
    }

    left.sort()
    right.sort()

    val totalDistance = left.zip(right)
        .sumOf { (l, r) -> kotlin.math.abs(l - r) }

    val rightCounts = right.groupingBy { it }.eachCount()

    var similarityScore = 0
    for (number in left) {
        val count = rightCounts[number] ?: 0
        similarityScore += number * count
    }

    println(totalDistance)
    println(similarityScore)
}
