import java.io.File

fun main() {
    val grid = File("input.txt").readLines()
    val word = "XMAS"
    val numRows = grid.size
    val numCols = grid[0].length
    var count = 0

    val directions = listOf(
        Pair(0, 1),
        Pair(1, 0),
        Pair(1, 1),
        Pair(1, -1),
        Pair(0, -1),
        Pair(-1, 0),
        Pair(-1, -1),
        Pair(-1, 1)
    )

    fun checkWord(row: Int, col: Int, rowDirection: Int, colDirection: Int): Boolean {
        for (i in 0 until 4) {
            val newRow = row + i * rowDirection
            val newCol = col + i * colDirection
            if (newRow !in 0 until numRows || newCol !in 0 until numCols || grid[newRow][newCol] != word[i]) {
                return false
            }
        }
        return true
    }

    for (row in 0 until numRows) {
        for (col in 0 until numCols) {
            for ((rowDirection, colDirection) in directions) {
                if (checkWord(row, col, rowDirection, colDirection)) {
                    count++
                }
            }
        }
    }

    println(count)

    count = 0

    fun checkMas(row: Int, col: Int, directions: List<Pair<Int, Int>>): Boolean {
        val word = "MAS"
        for ((index, direction) in directions.withIndex()) {
            val newRow = row + direction.first
            val newCol = col + direction.second
            if (newRow !in 0 until numRows || newCol !in 0 until numCols || grid[newRow][newCol] != word[index]) {
                return false
            }
        }
        return true
    }

    for (row in 1 until numRows - 1) {
        for (col in 1 until numCols - 1) {
            if (grid[row][col] == 'A') {
                val isXMas = (checkMas(row - 1, col - 1, listOf(0 to 0, 1 to 1, 2 to 2)) ||
                        checkMas(row - 1, col - 1, listOf(2 to 2, 1 to 1, 0 to 0))) &&
                        (checkMas(row - 1, col + 1, listOf(0 to 0, 1 to -1, 2 to -2)) ||
                                checkMas(row - 1, col + 1, listOf(2 to -2, 1 to -1, 0 to 0)))
                if (isXMas) {
                    count++
                }
            }
        }
    }

    println(count)
}
