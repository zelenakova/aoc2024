import java.io.File

fun main() {
    val text = File("input.txt").readLines().map { line ->
        line.split(" ").map { it.toInt() }
    }

    var safeCount = 0

    for (report in text) {
        val increasing = report.zipWithNext().all { (a, b) -> b > a && kotlin.math.abs(b - a) in 1..3 }
        val decreasing = report.zipWithNext().all { (a, b) -> b < a && kotlin.math.abs(b - a) in 1..3 }
        if (increasing || decreasing) {
            safeCount++
        }
    }

    var safeCountSecond = 0

    for (report in text) {
        val increasing = report.zipWithNext().all { (a, b) -> b > a && kotlin.math.abs(b - a) in 1..3 }
        val decreasing = report.zipWithNext().all { (a, b) -> b < a && kotlin.math.abs(b - a) in 1..3 }
        if (increasing || decreasing) {
            safeCountSecond++
        } else {
            for (i in report.indices) {
                val modifiedReport = report.subList(0, i) + report.subList(i + 1, report.size)
                val modifiedIncreasing = modifiedReport.zipWithNext().all { (a, b) -> b > a && kotlin.math.abs(b - a) in 1..3 }
                val modifiedDecreasing = modifiedReport.zipWithNext().all { (a, b) -> b < a && kotlin.math.abs(b - a) in 1..3 }
                if (modifiedIncreasing || modifiedDecreasing) {
                    safeCountSecond++
                    break
                }
            }
        }
    }

    println(safeCount)
    println(safeCountSecond) 
}
