import java.io.File

fun main() {
    val text = File("input.txt").readLines()
    var result = 0L
    for (line in text){
        val parts = line.split(":")
        val target = parts[0].toLong()
        val numbers = parts[1].trim().split(" ")
        val operators = generateOperators(numbers.size - 1)
        if (operators.any { evaluate(numbers, it) == target }) {
            result += target
        }
    }

    println(result)
}

fun evaluate(numbers: List<String>, operators: List<Char>): Long {
    var result = numbers[0].toLong()
    for (i in operators.indices){
        if (operators[i] == '+') {
            result += numbers[i+1].toLong()
        } else if (operators[i] == '*') {
            result *= numbers[i+1].toLong()
        } else if (operators[i] == '|') {
            result = (result.toString() + numbers[i+1]).toLong()
        }
    }
    return result
}

fun generateOperators(size: Int): List<List<Char>> {
    if (size == 0) {
        return mutableListOf(emptyList())
    }
    var new = generateOperators(size - 1)
    return new.flatMap { listOf(it + '+', it + '*', it + '|') }
}