import java.io.File

fun main() {
    var input = File("input.txt").readLines()[0].split(" ").map { it.toLong() }
    println(shift(input))
}

fun shift(input: List<Long>): Long {
    var finalCount = input.groupingBy { it }.eachCount().mapValues { it.value.toLong() }

    for (i in 0..74) {
        val helpCount = mutableMapOf<Long, Long>()
        for ((stone, count) in finalCount) {
            if (stone == 0L) {
                helpCount[1L] = helpCount.getOrDefault(1L, 0L) + count
            } else if (stone.toString().length % 2 == 0) {
                val left = stone.toString().substring(0, stone.toString().length / 2).toLong()
                val right = (stone.toString().substring(stone.toString().length / 2, stone.toString().length)).toLong()
                helpCount[left] = helpCount.getOrDefault(left, 0L) + count
                helpCount[right] = helpCount.getOrDefault(right, 0L) + count
            } else {
                helpCount[stone * 2024] = helpCount.getOrDefault(stone * 2024, 0L) + count
            }
        }
        finalCount = helpCount
    }
    return finalCount.values.sum()
}
