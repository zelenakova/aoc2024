package com.example.aoc

import java.io.File

fun main() {
    val guard = "^"
    var direction = Pair(-1,0)
    val wall = "#"

    val text = File("input.txt").readLines()

    val n = text.size
    var lab = Array(n) { Array<String>(n) { "." } }
    val path = Array(n) {Array(n) { mutableListOf<Pair<Int, Int>>() }}
    var count = Array(n) { Array<Int>(n) { 0 } }

    var i=0
    for (line: String in text) {
        var j=0
        for (one: Char in line) {
            lab[i][j] = one.toString()
            j++
        }
        i++
    }

    var position = searchGuard(lab, guard)
    if (position == null) {
        return
    }

    var dalej = true

    try {
        do {
            if (position != null) {
                val newPosition = sumPairs(position, direction)
                if (lab[newPosition.first][newPosition.second].contains(wall)) {
                    path[position.first][position.second].add(direction)
                    direction = rotate(direction)
                } else {
                    if (path[newPosition.first][newPosition.second].contains(direction)){
                        dalej = false
                        break
                    } else {
                        count[position.first][position.second] = 1
                        path[position.first][position.second].add(direction)
                        lab[position.first][position.second] = "X"
                        position = newPosition
                    }
                }
            }
        } while ((dalej == true) && (position != null))
    } catch (e: IndexOutOfBoundsException) {
        count[position.first][position.second] = 1
        path[position.first][position.second].add(direction)
        lab[position.first][position.second] = "X"
        println("Pocet krokov: ${count.flatten().sum()}")
    }
}

fun searchGuard(labarray: Array<Array<String>>, guard: String): Pair<Int, Int>? {
    for (row in labarray.indices) {
        for (column in labarray[row].indices) {
            if (labarray[row][column].contains(guard)) return Pair(row, column)
        }
    }
    return null
}

fun sumPairs(pair1: Pair<Int, Int>, pair2: Pair<Int, Int>): Pair<Int, Int> {
    return Pair(pair1.first + pair2.first, pair1.second + pair2.second)
}

fun rotate(oldDirection: Pair<Int, Int>): Pair<Int, Int> {
    return when (oldDirection) {
        Pair(-1,0) -> Pair(0,1)
        Pair(0,1) -> Pair(1,0)
        Pair(1,0) -> Pair(0,-1)
        Pair(0,-1) -> Pair(-1,0)
        else -> Pair(0,0)
    }
}